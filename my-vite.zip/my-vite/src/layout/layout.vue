<template>
  <div style="padding: 10px">
    {{$store.state.user.name}}
    <div>{{user}}</div>
    <div>{{num}} - {{str}} - {{male}}</div>
    <div>{{stateRefs}}</div>
    <a-button @click="gg">点击瞎几把调用</a-button>
    <a-button @click="change1">reactive</a-button>
    <a-button @click="change2">ref</a-button>
    <a-button @click="change3">toRefs</a-button>
  </div>
</template>

<script>
import API from '../api/api'
import {reactive, ref, toRefs} from 'vue'
export default {
  name: 'layout',
  data () {
    return {
      user: reactive({
        name: 'yhl',
        age: 18
      }),

      num: ref(0),
      str: ref(""),
      male: ref(true),

      stateRefs: {}
    }
  },

  mounted () {
  },

  methods: {
    change1 () {
      // 对象创建响应式状态
      this.user.name = 'Restia'

      this.$router.push({
        name: 'nav'
      })
    },
    change2 () {
      // 基本数据类型响应式状态
      console.log(this.num)
      this.num += 1
      this.str = 'new value'
      this.male = !this.male
    },
    change3 () {
      // 将响应式对象转化为普通对象
      console.log(this.stateRefs)
      this.stateRefs = toRefs(this.user)
      this.stateRefs.age ++
      console.log(this.stateRefs)
    },
    async gg () {
      let [err, res] = await API.demo.getCompany()
      console.log(err, res)
    }
  }
}
</script>

<style scoped>
</style>
