import axios from "axios"
import to from 'await-to-js'
let that = this
let prefix = (process.env.NODE_ENV === 'development') ? '' : '/dxh-manage/api'
let outUrl = function (url) {
  return prefix + url
}

const get = function (url, params) {
  let headers = {
    'Token': sessionStorage.getItem('admin_currentToken')
  }
  return to(new Promise((resolve, reject) => {
    axios.get(outUrl(url), {params, headers}).then(res => {
      if (res.data && res.data.code === '429') {
        alert('请勿频繁操作')
      }
      resolve(res.data)
    }).catch(err => {
      switch (err.response.status) {
        case 401: {
          window.vm.Logout(true)
          return
        }
        case 429: {
          alert('请勿频繁操作')
          return
        }
      }
      reject(err.response)
    })
  }))
}

const post = function (url, params) {
  params = params || {}
  let config = {
    headers: {
      'Content-Type': 'application/json',
      'Token': sessionStorage.getItem('admin_currentToken')
    }
  }
  return to(new Promise((resolve, reject) => {
    axios.post(outUrl(url), params, config).then(res => {
      if (res.headers.token) {
        resolve(res)
      } else {
        if (res.data && res.data.code === '429') {
          alert('请勿频繁操作')
        }
        resolve(res.data)
      }
    }).catch(err => {
      switch (err.response.status) {
        case 401: {
          window.vm.Logout(true)
          return
        }
        case 429: {
          alert('请勿频繁操作')
          return
        }
      }
      reject(err.response)
    })
  }))
}

const put = function (url, params) {
  let config = {
    headers: {
      'Content-Type': 'application/json',
      'Token': sessionStorage.getItem('admin_currentToken')
    }
  }
  return to(new Promise((resolve, reject) => {
    axios.put(outUrl(url), params, config).then(res => {
      if (res.data && res.data.code === '429') {
        alert('请勿频繁操作')
      }
      resolve(res.data)
    }).catch(err => {
      switch (err.response.status) {
        case 401: {
          window.vm.Logout(true)
          return
        }
        case 429: {
          alert('请勿频繁操作')
          return
        }
      }
      reject(err.response)
    })
  }))
}

const del = function (url, params) {
  let headers = {
    'Token': sessionStorage.getItem('admin_currentToken')
  }
  return to(new Promise((resolve, reject) => {
    axios.delete(outUrl(url), {params, headers}).then(res => {
      if (res.data && res.data.code === '429') {
        alert('请勿频繁操作')
      }
      resolve(res.data)
    }).catch(err => {
      switch (err.response.status) {
        case 401: {
          window.vm.Logout(true)
          return
        }
        case 429: {
          alert('请勿频繁操作')
          return
        }
      }
      reject(err.response)
    })
  }))
}

// 文件导出
const postFile = function (url, params) {
  params = params || {}
  let config = {
    headers: {
      'Content-Type': 'application/json;;charset=UTF-8',
      'Token': sessionStorage.getItem('admin_currentToken')
    },
    responseType: 'blob'
  }
  return to(new Promise((resolve, reject) => {
    axios.post(outUrl(url), params, config).then(res => {
      if (res.data && res.data.code === '429') {
        alert('请勿频繁操作')
      }
      if (res.data.code === '401' || res.data.code === 401) {
        window.vm.Logout(true)
      }
      resolve(res.data)
    }).catch(err => {
      switch (err.response.status) {
        case 401: {
          window.vm.Logout(true)
          return
        }
        case 429: {
          alert('请勿频繁操作')
          return
        }
      }
      reject(err.response)
    })
  }))
}

export default {
  get,
  post,
  put,
  del,
  postFile
}
