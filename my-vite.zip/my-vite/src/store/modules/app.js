const state = {
    sidebar: {
        withoutAnimation: false
    },
    device: 'desktop',
    wrapSize: {
        wrapWidth: window.innerWidth,
        wrapHeight: window.innerHeight
    }
}

const mutations = {
}

const actions = {
}

export default {
    namespaced: true,
    state,
    mutations,
    actions
}
