const state = {
    token: '',
    name: '测试标题',
    avatar: '',
    roles: [],
    menus: []
}

const mutations = {
}

const actions = {
}

export default {
    namespaced: true,
    state,
    mutations,
    actions
}
