const state = {
    routes: [],
    addRoutes: []
}

const mutations = {
}

const actions = {
}

export default {
    namespaced: true,
    state,
    mutations,
    actions
}
