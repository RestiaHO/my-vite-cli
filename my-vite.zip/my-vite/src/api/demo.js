import request from "../uilts/request";

const demo = {
  // 初始化token 通过身份证号获取token
  getCompany (params) {
    return request.get('/api/auto-data-entry/caseDataTemplate/TempSelectById?max=true', params)
  },
}

export default demo
