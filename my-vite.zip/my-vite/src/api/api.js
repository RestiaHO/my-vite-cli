import axios from "axios"
import demo from './demo'

function API () {
  this.demo = demo
}

// 拦截
axios.interceptors.response.use(res => {
  // if (res.data.code && res.data.code === '401') {
  //   window.vm.onLogout()
  //   window.vm.$refs.msg.showMessage('身份已过期', 'info')
  // }
  return res
}, error => {
  return Promise.reject(error)
})

export default new API()
