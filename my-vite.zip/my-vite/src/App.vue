<template>
  <div style="width: 100%; height: 100%">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
</style>
